import './PhaserGame'

const GameApp = () => {
  return (
    <>
      <div id="phaser-container"></div>
    </>
  )
}

export default GameApp;

