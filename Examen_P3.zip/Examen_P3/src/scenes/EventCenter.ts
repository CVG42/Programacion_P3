import Phaser from "phaser";

const instancia = new Phaser.Events.EventEmitter(); //Un emisor de Eventos de Phaser

export {
  instancia, //asi lo llamaremos desde otras clases
}